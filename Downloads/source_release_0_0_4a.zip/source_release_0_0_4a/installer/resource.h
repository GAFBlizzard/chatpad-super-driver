//
// Chatpad driver installation program resource file, generated with ResEdit 1.5.4,
//   modified by GAFBlizzard A.K.A. Blizzard A.K.A. AgentElrond, copyright 2010.
//
// This code is released under the MIT license.  See LICENSE.TXT for details.
//

#ifndef RESOURCE_H
#define RESOURCE_H

#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif // IDC_STATIC

#define IDD_DIALOG1                             100

#ifndef IDCANCEL
#define IDCANCEL                                1001
#endif // IDCANCEL

//***
// Dialog buttons
//***

#define NUM_DIALOG_BUTTONS                      3

#define IDC_EXIT_BUTTON                         1006
#define IDC_INSTALL_BUTTON                      1007
#define IDC_UNINSTALL_BUTTON                    1008

//***
// Dialog status display
//***

#define IDC_UTILITY_STATUS                      1100

#endif // RESOURCE_H

