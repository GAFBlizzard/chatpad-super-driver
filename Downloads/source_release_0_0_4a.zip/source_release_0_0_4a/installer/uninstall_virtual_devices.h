//
// Chatpad virtual device uninstaller, by GAFBlizzard A.K.A. Blizzard A.K.A. AgentElrond, copyright 2010.
//
// This code is released under the MIT license.  See LICENSE.TXT for details.
//

#ifndef UNINSTALL_VIRTUAL_DEVICES_H
#define UNINSTALL_VIRTUAL_DEVICES_H


// Function prototypes.

// Uninstalls a virtual keyboard device.  Returns SUCCESS on success and FAILURE on failure.
int UninstallVirtualKeyboardDevice(void);

// Uninstalls a virtual mouse device.  Returns SUCCESS on success and FAILURE on failure.
int UninstallVirtualMouseDevice(void);

#endif // UNINSTALL_VIRTUAL_DEVICES_H

